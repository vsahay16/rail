# cancellation-and-refunds — English

https://railq.in/guides/cancellation-and-refunds

## Choose the correct situation first

Start with the reason money should be returned: you changed your plans, the railway disrupted the service, a booking failed, or only some passengers will travel. These are different workflows. This page helps you choose the right next step; it does not cancel your ticket or establish the final amount. Keep the ticket type and booking channel alongside the reason.

## Read the 2026 update before using a deadline

The Ministry’s March 2026 announcement revises the former 48/12/4-hour cancellation windows to 72/24/8 hours and describes changes to refund processing. Older official instructions remain accessible. Do not treat an older online table or calculator as proof of the rule for your ticket. Confirm the applicable conditions and action in the authorised booking service; ask support promptly if they are unclear.

## If you are cancelling voluntarily

Open the reservation through the service used to purchase it. Check every passenger selected, current status, fare breakdown and the amount shown before confirming. After submitting, save the acknowledgement and revised ticket if anyone is still travelling. A message saying the request was received is not necessarily evidence that a bank credit has completed.

## If a train is disrupted or a booking failed

Verify the actual event before selecting a reason. A train cancellation, diversion and late arrival are not interchangeable. A payment debit with no issued ticket is a separate transaction issue. Follow the matching guide below instead of using voluntary cancellation to resolve every problem. This avoids cancelling a valid ticket merely to investigate another failed payment.

- [Cancelled or delayed train](https://railq.in/guides/train-cancelled-delayed-refund)

- [Money debited without a ticket](https://railq.in/guides/irctc-money-debited-ticket-not-booked)

## For a family booking, decide who will travel

Record each passenger’s intention separately before taking action. All passengers staying home differs from one person travelling and another not travelling. Read the current claim instructions and any evidence requirement. Do not infer an automatic refund for an unused companion’s place, or assume one confirmed row confirms everyone.

- [Mixed-status family bookings](https://railq.in/guides/partially-confirmed-family-ticket)

## Follow up with evidence, not a second guess

Keep the transaction reference, cancellation or claim acknowledgement, date, amount and support case number. Compare the credited amount with the actual refund breakdown, including separately charged fees. Follow up through the original seller and payment provider as appropriate. Never share OTPs, passwords or unmasked bank statements in public comments.

Sources:

- [Ministry of Railways: 24 March 2026 reform announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2244597)

- [IRCTC: official booking service](https://www.irctc.co.in/)

# cancellation-and-refunds — हिंदी

https://railq.in/hi/guides/cancellation-and-refunds

## पहले सही स्थिति पहचानें

पहले तय करें पैसे वापस क्यों मिलने चाहिए: आपकी योजना बदली, रेलवे सेवा प्रभावित हुई, बुकिंग असफल हुई या केवल कुछ यात्री जाएँगे। इनकी प्रक्रियाएँ अलग हैं। यह पेज सही अगला कदम चुनने में मदद करता है; टिकट रद्द या अंतिम रकम तय नहीं करता। कारण के साथ टिकट प्रकार और बुकिंग माध्यम भी देखें।

## समय-सीमा अपनाने से पहले 2026 अपडेट देखें

मंत्रालय की मार्च 2026 घोषणा में पुरानी 48/12/4 घंटे की रद्दीकरण सीमाएँ 72/24/8 घंटे की गई हैं और रिफंड प्रक्रिया में बदलाव बताए गए हैं। पुराने आधिकारिक निर्देश भी ऑनलाइन हैं। पुरानी तालिका या कैलकुलेटर को अपने टिकट का अंतिम नियम न मानें। अधिकृत बुकिंग सेवा में लागू शर्तें और कार्रवाई देखें; अस्पष्टता हो तो तुरंत सहायता लें।

## खुद यात्रा रद्द करनी हो

जिस सेवा से टिकट खरीदा, उसमें आरक्षण खोलें। पुष्टि से पहले चुने हुए यात्री, वर्तमान स्थिति, किराया विवरण और दिखाई गई रकम जाँचें। जमा करने के बाद रसीद और किसी के यात्रा करने पर नया टिकट रखें। अनुरोध मिलने का संदेश बैंक में रकम जमा होने का प्रमाण जरूरी नहीं है।

## ट्रेन प्रभावित हो या बुकिंग असफल हो

कारण चुनने से पहले वास्तविक घटना जाँचें। ट्रेन रद्द होना, मार्ग बदलना और देर से पहुँचना एक जैसे नहीं हैं। टिकट बने बिना पैसे कटना अलग लेन-देन समस्या है। हर समस्या में सामान्य रद्दीकरण करने के बजाय नीचे संबंधित गाइड देखें। इससे दूसरे असफल भुगतान की जाँच में सही टिकट गलती से रद्द नहीं होगा।

- [रद्द या लेट ट्रेन](https://railq.in/hi/guides/train-cancelled-delayed-refund)

- [टिकट बने बिना पैसे कटे](https://railq.in/hi/guides/irctc-money-debited-ticket-not-booked)

## परिवार की बुकिंग में तय करें कौन जाएगा

कार्रवाई से पहले हर यात्री का निर्णय अलग लिखें। कोई भी न जाए और एक जाए, दूसरा न जाए—ये अलग स्थितियाँ हैं। वर्तमान दावा निर्देश और प्रमाण की जरूरत पढ़ें। साथ न गए व्यक्ति का रिफंड स्वतः मिलने या एक कन्फर्म पंक्ति से सब कन्फर्म होने का अनुमान न लगाएँ।

- [परिवार की मिली-जुली स्थिति](https://railq.in/hi/guides/partially-confirmed-family-ticket)

## अनुमान के बजाय प्रमाण से फॉलो-अप करें

लेन-देन संदर्भ, रद्दीकरण या दावा रसीद, तारीख, रकम और शिकायत नंबर रखें। जमा रकम को वास्तविक रिफंड विवरण और अलग शुल्क से मिलाएँ। जरूरत के अनुसार मूल विक्रेता और भुगतान सेवा से फॉलो-अप करें। सार्वजनिक टिप्पणी में OTP, पासवर्ड या बिना छिपाया बैंक स्टेटमेंट न दें।

Sources:

- [Ministry of Railways: 24 March 2026 reform announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2244597)

- [IRCTC: official booking service](https://www.irctc.co.in/)

# chart-preparation — English

https://railq.in/guides/chart-preparation

## Use chart status to make a travel decision

Chart preparation updates reservation allocations. Read the actual charting status and every passenger’s current reservation, rather than treating an estimated time as confirmation. A blank coach or berth field needs verification; it is not an invitation to choose an empty berth. The chart also does not establish the platform you will board from.

- [Check the actual PNR record](https://railq.in/pnr-status)

## Why older chart-time articles disagree

Charting instructions have changed. The March 2026 Ministry announcement describes advance charting 9–18 hours before departure, so the earlier eight-hour guidance should not be presented as a universal current rule. This announcement is not a train-specific chart timetable. Use the official status for the correct service and date instead of deriving boarding permission from a generic countdown.

## Origin date and boarding date can differ

Imagine a train that starts on Monday evening and reaches your station on Tuesday morning. Keep both dates and stations clear when checking the journey. A search using the wrong date can produce a plausible-looking but irrelevant result. Verify the train number and boarding point together; your local departure time alone may not identify the applicable charting arrangement.

- [Check the service and boarding stop](https://railq.in/train-schedule)

## After charting, choose the right passenger guide

An RAC outcome, an entirely waitlisted e-ticket and a mixed family PNR need different decisions. First check all passenger rows. Then use the relevant guide to understand accommodation and the next action. A status prediction made earlier does not override the current railway record.

- [RAC accommodation](https://railq.in/guides/can-you-travel-with-rac-ticket)

- [Fully waitlisted after charting](https://railq.in/guides/waitlisted-ticket-after-chart-preparation)

- [Mixed family PNR](https://railq.in/guides/partially-confirmed-family-ticket)

## Can a fresh ticket still be available?

Current booking can offer vacant accommodation after charting within the permitted booking window. Check the exact station pair and service rather than assuming no more tickets can be sold. Treat a new purchase separately from an existing booking and verify the issued ticket. Do not buy a departure you cannot safely reach.

- [How current booking works](https://railq.in/guides/current-booking-after-chart)

## If the result has not updated

Compare the result timestamp with the time you checked and verify through official enquiry. A provider delay is different from railway charting being incomplete. Avoid refreshing many services repeatedly. If you report a display issue, share the page name and error, with PNR and passenger details hidden.

Sources:

- [Ministry of Railways: 24 March 2026 reform announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2244597)

- [Indian Railways: official PNR enquiry](https://www.indianrail.gov.in/enquiry/PNR/PnrEnquiry.html?locale=en)

- [IRCTC: current booking](https://contents.irctc.co.in/en/currentBooking.html)

# chart-preparation — हिंदी

https://railq.in/hi/guides/chart-preparation

## यात्रा निर्णय के लिए चार्ट स्थिति देखें

चार्ट बनने पर आरक्षण आवंटन अपडेट होता है। अनुमानित समय को पुष्टि मानने के बजाय वास्तविक चार्ट स्थिति और हर यात्री का वर्तमान आरक्षण देखें। खाली कोच या बर्थ की जानकारी सत्यापित करें; खाली बर्थ चुन लेने की अनुमति न मानें। चार्ट बोर्डिंग प्लेटफॉर्म भी तय नहीं करता।

- [वास्तविक PNR रिकॉर्ड देखें](https://railq.in/hi/pnr-status)

## पुराने चार्ट समय वाले लेख अलग क्यों हैं?

चार्ट संबंधी निर्देश बदले हैं। मार्च 2026 की मंत्रालय घोषणा प्रस्थान से 9–18 घंटे पहले अग्रिम चार्टिंग बताती है; इसलिए पुरानी आठ घंटे वाली जानकारी को हर ट्रेन का मौजूदा नियम न बताएँ। घोषणा किसी खास ट्रेन की चार्ट समय-सारिणी नहीं है। सामान्य काउंटडाउन से बोर्डिंग अनुमति निकालने के बजाय सही ट्रेन और तारीख की आधिकारिक स्थिति देखें।

## शुरुआत और बोर्डिंग की तारीख अलग हो सकती है

मान लें ट्रेन सोमवार शाम शुरू होकर मंगलवार सुबह आपके स्टेशन आती है। जाँच में दोनों तारीखें और स्टेशन स्पष्ट रखें। गलत तारीख का परिणाम सही दिखते हुए भी आपकी यात्रा का नहीं हो सकता। ट्रेन नंबर और बोर्डिंग स्टेशन साथ मिलाएँ; केवल स्थानीय प्रस्थान समय से लागू चार्ट व्यवस्था तय नहीं होती।

- [ट्रेन और बोर्डिंग ठहराव देखें](https://railq.in/hi/train-schedule)

## चार्ट के बाद सही यात्री गाइड चुनें

RAC, पूरी तरह वेटलिस्ट ई-टिकट और परिवार के मिली-जुली स्थिति वाले PNR में अलग निर्णय चाहिए। पहले सभी यात्री पंक्तियाँ देखें, फिर संबंधित गाइड से जगह और अगला कदम समझें। पहले की गई संभावना वर्तमान रेलवे रिकॉर्ड की जगह नहीं लेती।

- [RAC की जगह](https://railq.in/hi/guides/can-you-travel-with-rac-ticket)

- [चार्ट के बाद पूरी वेटलिस्ट](https://railq.in/hi/guides/waitlisted-ticket-after-chart-preparation)

- [परिवार का मिश्रित PNR](https://railq.in/hi/guides/partially-confirmed-family-ticket)

## क्या नया टिकट अब भी मिल सकता है?

अनुमत बुकिंग अवधि में चार्ट के बाद खाली जगह करंट बुकिंग में मिल सकती है। टिकट अब नहीं मिलेंगे मानने के बजाय सही स्टेशन जोड़ी और ट्रेन देखें। नई खरीद को पुरानी बुकिंग से अलग समझें और जारी टिकट जाँचें। सुरक्षित रूप से न पहुँच सकने वाली ट्रेन न खरीदें।

- [करंट बुकिंग कैसे काम करती है](https://railq.in/hi/guides/current-booking-after-chart)

## परिणाम अपडेट न हुआ हो

परिणाम का समय जाँच के समय से मिलाएँ और आधिकारिक पूछताछ से पुष्टि करें। प्रदाता की देरी और रेलवे चार्ट अधूरा होना अलग हैं। कई सेवाएँ बार-बार रिफ्रेश न करें। स्क्रीन की समस्या बताएँ तो पेज और त्रुटि दें, PNR और यात्री विवरण छिपाएँ।

Sources:

- [Ministry of Railways: 24 March 2026 reform announcement](https://www.pib.gov.in/PressReleasePage.aspx?PRID=2244597)

- [Indian Railways: official PNR enquiry](https://www.indianrail.gov.in/enquiry/PNR/PnrEnquiry.html?locale=en)

- [IRCTC: current booking](https://contents.irctc.co.in/en/currentBooking.html)

# festival-travel-planning — English

https://railq.in/guides/festival-travel-planning

## Plan the outward and return journeys together

Start with the dates you must be present, the people travelling and your maximum total budget. Compare a small range of departure dates and acceptable classes before settling on one train. Book and verify the return journey too. A workable outbound ticket is not a complete plan if the return would disrupt work, school or an onward booking.

## Check a festival special by number and operating date

A forwarded poster may describe an old season or only selected operating days. Match the train number, boarding date, stopping pattern and booking availability through official railway channels. Read the announcement date separately from the journey dates. Do not treat a proposed service, an announcement or an old screenshot as a booked seat.

- [Verify the timetable](https://railq.in/train-schedule)

- [Check the actual travel date](https://railq.in/seat-availability)

## Compare nearby stations before paying

A nearby terminal can widen your options, but add its transfer cost and travel time before comparing fares. Once booked, follow the recorded boarding point. For example, PNBE and RJPB are different stations; a family message saying only “Patna station” can send people to different places. Send the code and full name together.

- [Patna-area station comparison](https://railq.in/guides/patna-junction-rajendra-nagar-danapur-stations)

- [Delhi station codes](https://railq.in/guides/delhi-railway-stations-codes)

- [Mumbai terminals](https://railq.in/guides/mumbai-railway-terminals-codes)

## Set a decision point for an uncertain ticket

Agree when you will review a waitlisted booking and choose an alternative if necessary. Base that decision on the latest passenger status, your arrival deadline and the cost of changing plans. A confirmation prediction is not a commitment. Avoid holding several speculative tickets without understanding their cancellation conditions and the amount tied up in payments.

- [Understand waiting-list categories](https://railq.in/guides/gnwl-rlwl-pqwl-tqwl-difference)

## Make the station plan usable by everyone

Keep bags manageable and choose a meeting point away from platform edges. Share the train number and station code with every adult. Keep essential medicines, water and required documents accessible, and retain the ticket offline. Plan around the slowest traveller; do not separate children from their accompanying adult while rushing to another platform.

## Protect the onward connection

A crowded-station transfer requires more than the time shown for a road journey. Include exiting, transport waiting, entry checks and reaching the coach. For a flight or separately booked train, decide in advance what you will do if the incoming service is late. Do not assume the second booking is protected automatically.

- [Plan a transfer margin](https://railq.in/connection-buffer-calculator)

- [If a connection is missed](https://railq.in/guides/missed-train-what-to-do)

Sources:

- [Indian Railways: official PNR enquiry](https://www.indianrail.gov.in/enquiry/PNR/PnrEnquiry.html?locale=en)

- [Indian Railways: National Train Enquiry System](https://enquiry.indianrail.gov.in/mntes/)

# festival-travel-planning — हिंदी

https://railq.in/hi/guides/festival-travel-planning

## जाने और लौटने की यात्रा साथ तय करें

जरूरी पहुँचने की तारीख, यात्रियों और कुल बजट से शुरुआत करें। एक ट्रेन तय करने से पहले कुछ तारीखें और स्वीकार्य श्रेणियाँ देखें। वापसी भी बुक करके जाँचें। लौटने में काम, स्कूल या आगे की बुकिंग बिगड़े तो केवल जाने का टिकट पूरी योजना नहीं है।

## विशेष ट्रेन का नंबर और चलने की तारीख जाँचें

फॉरवर्ड पोस्टर पुराने सीजन या केवल कुछ दिनों की ट्रेन का हो सकता है। आधिकारिक रेलवे माध्यम से ट्रेन नंबर, बोर्डिंग तारीख, ठहराव और बुकिंग उपलब्धता मिलाएँ। घोषणा की तारीख को यात्रा की तारीख से अलग पढ़ें। प्रस्तावित सेवा, घोषणा या पुराने स्क्रीनशॉट को बुक की गई सीट न मानें।

- [समय-सारिणी जाँचें](https://railq.in/hi/train-schedule)

- [वास्तविक तारीख की उपलब्धता देखें](https://railq.in/hi/seat-availability)

## भुगतान से पहले पास के स्टेशन तुलना करें

पास का टर्मिनल विकल्प बढ़ा सकता है, पर किराया तुलना से पहले वहाँ पहुँचने का खर्च और समय जोड़ें। बुकिंग के बाद दर्ज बोर्डिंग स्टेशन मानें। उदाहरण के लिए PNBE और RJPB अलग हैं; परिवार को केवल “पटना स्टेशन” कहने से लोग अलग जगह पहुँच सकते हैं। कोड और पूरा नाम साथ भेजें।

- [पटना क्षेत्र के स्टेशन](https://railq.in/hi/guides/patna-junction-rajendra-nagar-danapur-stations)

- [दिल्ली स्टेशन कोड](https://railq.in/hi/guides/delhi-railway-stations-codes)

- [मुंबई टर्मिनल](https://railq.in/hi/guides/mumbai-railway-terminals-codes)

## अनिश्चित टिकट के लिए निर्णय का समय तय करें

तय करें वेटलिस्ट बुकिंग कब देखकर जरूरत पर दूसरा विकल्प चुनेंगे। ताजा यात्री स्थिति, पहुँचने की जरूरत और योजना बदलने की लागत देखें। कन्फर्मेशन की संभावना वादा नहीं है। रद्दीकरण शर्तें और फँसी रकम समझे बिना कई अनुमान-आधारित टिकट न रखें।

- [वेटलिस्ट श्रेणियाँ समझें](https://railq.in/hi/guides/gnwl-rlwl-pqwl-tqwl-difference)

## स्टेशन की योजना सबके लिए आसान रखें

सामान संभालने योग्य रखें और प्लेटफॉर्म किनारे से दूर मिलने की जगह तय करें। हर वयस्क को ट्रेन नंबर और स्टेशन कोड दें। जरूरी दवा, पानी और दस्तावेज पास रखें तथा टिकट ऑफलाइन रखें। सबसे धीमे यात्री के हिसाब से चलें; प्लेटफॉर्म बदलने की जल्दी में बच्चे को साथ वाले वयस्क से अलग न करें।

## आगे का कनेक्शन सुरक्षित रखें

भीड़ वाले स्टेशन में ट्रांसफर के लिए सड़क यात्रा से अधिक समय चाहिए। बाहर निकलना, वाहन का इंतजार, प्रवेश जाँच और कोच तक पहुँचना जोड़ें। उड़ान या अलग बुक ट्रेन हो तो पहली ट्रेन लेट होने पर अगला कदम पहले तय करें। दूसरी बुकिंग स्वतः सुरक्षित न मानें।

- [ट्रांसफर का अतिरिक्त समय देखें](https://railq.in/hi/connection-buffer-calculator)

- [कनेक्शन छूट जाए तो](https://railq.in/hi/guides/missed-train-what-to-do)

Sources:

- [Indian Railways: official PNR enquiry](https://www.indianrail.gov.in/enquiry/PNR/PnrEnquiry.html?locale=en)

- [Indian Railways: National Train Enquiry System](https://enquiry.indianrail.gov.in/mntes/)