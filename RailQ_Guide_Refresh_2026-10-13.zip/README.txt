RailQ existing-guide refresh — 13 October 2026

Updates three existing guides in English and Hindi. No new URLs.
Requires the completed 7 October twelve-article package and earlier three-article package.
This patch is based on the source used for those deliveries. If you have independently edited the three listed files since then, merge the changes rather than overwriting your edits.

UPLOAD
1. Back up your GitHub repository.
2. Extract this ZIP.
3. At the ROOT of github.com/vsahay16/rail choose Add file > Upload files.
4. Drag ONLY the extracted RailSahayak_Complete_NextJS_Project folder.
5. Confirm THREE project files, then commit together. Do not delete folders or nest the project folder inside itself.
6. Wait for Vercel Ready, then open the three English pages and Hindi equivalents.

UPDATED URLS
https://railq.in/guides/cancellation-and-refunds
https://railq.in/guides/chart-preparation
https://railq.in/guides/festival-travel-planning
https://railq.in/hi/guides/cancellation-and-refunds
https://railq.in/hi/guides/chart-preparation
https://railq.in/hi/guides/festival-travel-planning

The existing registry, metadata and sitemap retain these URLs. Their last-modified dates update to 13 October 2026. No new sitemap submission, SQL, API key or environment-variable change is needed. The previous fifteen articles remain registered.

WHY THESE UPDATES
Refunds: a decision hub linking to failed payment, disruption and family-ticket guides. It does not duplicate their detailed instructions.
Chart preparation: removes the old universal eight-hour statement, explains source changes and links to the correct post-chart decisions.
Festival planning: adds workable outbound/return planning, special-train verification, nearby terminal comparisons and connection preparation. It does not invent announced special trains, available seats or festival-specific timetables.

SOURCE LIMITS
The Ministry announcement was checked on 13 October 2026. Older official documents and newer announcements remain inconsistent. The articles distinguish announcements from booking-level eligibility and do not claim account-level rollout verification. The IRCTC refund PDF rejected the fresh retrieval; it is not labelled freshly verified in this patch. Sources and Hindi text are included on the pages.

OUTSTANDING TOOL ISSUE
Refund and chart calculator logic is NOT changed by this content-only patch. The earlier audit found older refund brackets in code. Those tools need separate reconciliation with applicable current rules before their estimates can be advertised as current. The updated guides avoid presenting calculator outputs as authoritative.

CHECKS
Production build and TypeScript passed. Local route checks cover the six refreshed English/Hindi pages, self-canonicals, language tags, update dates, sitemap inclusion and internal link targets. This is not a live deployment or a mobile visual test.
