RailQ calculator update — 13 October 2026

INSTALLATION
1. Download a backup of your GitHub repository.
2. Extract this ZIP. It contains a RailSahayak_Complete_NextJS_Project folder with FOUR code files.
3. Open https://github.com/vsahay16/rail at the repository ROOT (not inside the project folder).
4. Choose Add file > Upload files. Drag the extracted RailSahayak_Complete_NextJS_Project folder into the upload area.
5. Check that the four paths match the existing project paths. There must not be app/app or two nested project folders. Do not delete existing folders. Commit the four files together.
6. Wait for Vercel to show Ready. No SQL, dependency or environment-variable change is required.
7. Open the six URLs below and test. Deploy this after the article and guide packages already supplied; these files preserve that working version. If you changed these four files separately since then, merge those edits before uploading.

PAGES
https://railq.in/refund-calculator
https://railq.in/cancellation-deadline-calculator
https://railq.in/chart-preparation-calculator
https://railq.in/hi/refund-calculator
https://railq.in/hi/cancellation-deadline-calculator
https://railq.in/hi/chart-preparation-calculator

CHANGES AND LIMITATIONS
- Ordinary confirmed-ticket refund estimates use the announced 2026 72/24/8-hour thresholds, replacing 48/12/4.
- Retains published per-passenger class minimums and RAC/waitlist clerkage; excludes GST and service fees. The final booking-service cancellation quote takes priority. Older official documents still show different thresholds; the tool makes this limitation visible.
- Explicitly select special policy / unsure for Vande Bharat Sleeper, Amrit Bharat II, or other services with separate refund conditions. This selection deliberately produces no numerical estimate.
- Confirmed Tatkal voluntary cancellation returns no ordinary refund. Cancelled trains, exceptional claims and mixed-status tickets are outside this calculation.
- Cancellation deadlines use the same shared thresholds. Confirmed Tatkal does not receive a misleading refundable deadline.
- Chart tool uses the Ministry's broad 9–18-hour planning range. This is NOT a verified timetable for an individual train, a guarantee, a countdown to confirmation or a live chart status. An exact universal 2026 charting formula was not established from the primary sources reviewed. Verify your charting station and official PNR status.
- English and Hindi labels, warnings and sources updated together; six sitemap lastmod values updated.

CHECK AFTER DEPLOYMENT
Refund: ordinary ticket, total fare 2000, one passenger, Sleeper, confirmed.
73 hours => 1880; 72 => 1500; 24 => 1500; 23 => 1000; 8 => 1000; 7 => 0.
Tatkal confirmed => 0 for voluntary cancellation.
Special policy / unsure => guidance, no amount.
Chart: 1 January 2027 at 04:00 IST => planning markers 31 December 2026 at 10:00 and 19:00 IST.
Repeat in Hindi. Check current official booking terms before making a real cancellation; do not wait for the final cutoff.

VALIDATION
Production Next.js build and TypeScript check passed.
Calculation tests passed for exact boundaries, fare cap, class minimums, Tatkal, RAC/waitlist, paise precision, invalid inputs, shared deadlines, leap day, year rollover and IST conversion.
Six local English/Hindi page responses and six sitemap modification dates passed.
No live deployment, real ticket cancellation or PNR lookup was performed. Browser-based form interaction has not been independently tested.

SOURCES
Ministry of Railways announcement, 24 March 2026:
https://www.pib.gov.in/PressReleasePage.aspx?PRID=2244597
PIB New India Samachar, 16–30 April 2026, page 7:
https://newindiasamachar.pib.gov.in/WriteReadData/flipbook/2026/Apr/2nd/English/files/basic-html/page7.html
Government broadcaster report, 24 March 2026:
https://newsonair.gov.in/railways-minister-ashwini-vaishnaw-launches-five-reforms-in-railways-52-reforms-in-52-weeks-drive/
IRCTC published detailed refund rules (older policy text; read in the previous guide review; refetch blocked on 13 October):
https://contents.irctc.co.in/en/RefundCancellationRules.pdf
